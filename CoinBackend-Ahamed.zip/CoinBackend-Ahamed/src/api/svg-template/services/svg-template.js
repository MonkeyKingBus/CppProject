'use strict';

/**
 * svg-template service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::svg-template.svg-template');
