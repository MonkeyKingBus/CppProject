'use strict';

/**
 * svg-template controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::svg-template.svg-template');
